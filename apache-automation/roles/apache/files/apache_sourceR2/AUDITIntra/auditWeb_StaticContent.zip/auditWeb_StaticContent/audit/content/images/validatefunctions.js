// Returns true if a given string is numeric. False otherwise.
function IsNumeric(strNumber)
{
	var blnIsNumber = true;
	var blnIsFound = false;
	
	for (intCurChar = 0; intCurChar < strNumber.length && blnIsNumber == true; intCurChar++)
	{
		if (((strNumber.substring(intCurChar, intCurChar + 1) < "0") 
			 ||
		    (strNumber.substring(intCurChar, intCurChar + 1) > "9"))
		     && (strNumber.substring(intCurChar, intCurChar + 1) != "."))
		{
			blnIsNumber = false;
		}
		if ((strNumber.substring(intCurChar, intCurChar + 1) == ".")
			&& (blnIsFound == true))
		{
			blnIsNumber = false;
		}
		if ((strNumber.substring(intCurChar, intCurChar + 1) == ".")
			&& (blnIsFound == false))
		{
			blnIsFound = true;
		}
	}
	return (blnIsNumber);
} // IsNumeric()

// Returns the numeric value of given string number.
// This is a wraper function for the build-in function eval() because eval()
// gives a syntax error of "; expected" when invoke with eval("08") or eval("09")
function GetNumericVal(strNumber)
{
	var numRtnVal = 0;
	
	if (strNumber == "08")
	{
		numRtnVal = 8;
	}
	else if (strNumber == "09")
	{
		numRtnVal = 9;
	}
	else
	{
		numRtnVal = eval(strNumber);
	}
	
	return numRtnVal;
}

// Returns true if a given year is a Leap Year. False otherwise.
// Leap Years: are those occurs every four years, except for
//             years ending in 00, in which case only if the
//			   year is divisible by 400.
function IsLeapYear(strYear)
{
	var blnLeapYear = false;
	var intYearMod = GetNumericVal(strYear) % 4;
	
	if (intYearMod == 0)
	{
		if ((GetNumericVal(strYear) % 100) == 0 && (GetNumericVal(strYear) % 400) != 0) {
			blnLeapYear = false;
		}
		else {
			blnLeapYear = true;
		}
	}
	
	return (blnLeapYear);
}  // IsLeapYear()


// Returns true if a given date is valid. False otherwise.
// Note: the strings strYear must be a valid year of the format YYYY.
//       strMonth must be a valid month of the format MM.
function IsValidDay(strYear, strMonth, strDay)
{
	var blnValidDay = false;
	var intYear = parseInt(strYear, 10);
	var intMonth = parseInt(strMonth, 10);
	var intDay = parseInt(strDay, 10);

	if (intMonth == 1 || intMonth == 3  || intMonth == 5 || intMonth == 7 || 
	    intMonth == 8 || intMonth == 10 || intMonth == 12)
	{
		blnValidDay = intDay < 32;
	}
	if (intMonth == 4 || intMonth == 6 || intMonth == 9 || intMonth == 11)
	{
		blnValidDay = intDay < 31;
	}
	
	if (intMonth == 2)
	{
		if (IsLeapYear(strYear)){
			blnValidDay = intDay < 30;
		}
		else {
			blnValidDay = intDay < 29;
		}
	}

	return (blnValidDay);
}  // IsValidDay()


// Returns true if a given string is a date of the format YYYY/MM/DD. False otherwise.
function IsValidDate(strDate)
{

	// Date must be exactly 10 characters
	if (strDate.length != 10)
	{
		return false;
	}
	
	var strYear  = strDate.substring(0, 4);
	var strMonth = strDate.substring(5, 7);
	var strDay   = strDate.substring(8, 10);
	var strSep1 = strDate.substring(4, 5);		// First separator
	var strSep2 = strDate.substring(7, 8);		// Second separator

	// Year, month and day must be numeric.
	if (IsNumeric(strYear) != true || IsNumeric(strMonth) != true || IsNumeric(strDay) != true)
	{
		return false;
	}
	
	// Month must be less than 13 and day less than 32
	if (GetNumericVal(strMonth) > 12)
	{
		return false;
	}

	// Month must be less than 13 and day less than 32
	if (GetNumericVal(strDay) > 31)
	{
		return false;
	}

	//All separators must be a forward slash
	if (strSep1 != "/" || strSep2 != "/" )
	{
		return false;
	}

	if (!IsValidDay(strYear, strMonth, strDay))
	{
		return false;
	}

	return true;
}  // IsValidDate()


// Given strings are date of the format YYYY/MM/DD.
// Returns:
//		 1 if strDate1 > strDate2 (i.e. strDate1 is  more recent compared to strDate2)
//		 0 if strDate1 = strDate2
//		-1 if strDate1 < strDate2 (i.e. strDate2 is  more recent compared to strDate1)
//    -100 any other errors

function CompareDate(strDate1, strDate2)
{
	var intRtnVal = -100;

	// Each date must be exactly 10 characters
	if (strDate1.length != 10 || strDate2.length != 10)
	{
		return intRtnVal;
	}
	
	var intYear1  = GetNumericVal(strDate1.substring(0, 4));
	var intMonth1 = GetNumericVal(strDate1.substring(5, 7));
	var intDay1   = GetNumericVal(strDate1.substring(8, 10));
	var intYear2  = GetNumericVal(strDate2.substring(0, 4));
	var intMonth2 = GetNumericVal(strDate2.substring(5, 7));
	var intDay2   = GetNumericVal(strDate2.substring(8, 10));

	intRtnVal = 0;
	// Check for strDate1 = strDate2
	if (intYear1 == intYear2 && intMonth1 == intMonth2 && intDay1 == intDay2)
	{
		return intRtnVal;
	}

	intRtnVal = 1;
	// Check for strDate1 > strDate2
	if ( intYear1 > intYear2 ||
		(intYear1 == intYear2 && intMonth1  > intMonth2) ||
		(intYear1 == intYear2 && intMonth1 == intMonth2 && intDay1 > intDay2)
	   )
	{
		return intRtnVal;
	}

	intRtnVal = -1;
	// Check for strDate1 > strDate2
	if ( intYear2 > intYear1 ||
		(intYear2 == intYear1 && intMonth2  > intMonth1) ||
		(intYear2 == intYear1 && intMonth2 == intMonth1 && intDay2 > intDay1)
	   )
	{
		return intRtnVal;
	}

	intRtnVal = -100;

	return intRtnVal;
}  // CompareDate()


// Returns true if a given string is a time of the format HH:MM:SS. False otherwise.
function IsValidTime(strTime)
{

	// Date must be exactly 8 characters
	if (strTime.length != 8)
	{
		return false;
	}

	var strHour   = strTime.substring(0, 2);
	var strMinute = strTime.substring(3, 5);
	var strSecond = strTime.substring(6, 8);
	var strSep1   = strTime.substring(2, 3);		// First separator
	var strSep2   = strTime.substring(5, 6);		// Second separator

	// Hour, minute and second must be numeric.
	if (IsNumeric(strHour) != true || IsNumeric(strMinute) != true ||  IsNumeric(strSecond) != true)
	{
		return false;
	}

	// Hour must be less than 24, minute and second less than 60
	if (GetNumericVal(strHour) > 23 ||  GetNumericVal(strMinute) > 59 ||  GetNumericVal(strSecond) > 59)
	{
		return false;
	}

	//All separators must be a column
	if (strSep1 != ":" || strSep2 != ":" )
	{
		return false;
	}

	return true;
}  // IsValidTime()


// Given strings are date of the format HH:MM:SS
// Returns:
//		 1 if strTime1 > strTime2 (i.e. strTime1 is  more recent compared to strTime2)
//		 0 if strTime1 = strTime2
//		-1 if strTime1 < strTime2 (i.e. strTime2 is  more recent compared to strTime1)
//    -100 any other errors

function CompareTime(strTime1, strTime2)
{
	var intRtnVal = -100;

	// Each date must be exactly 8 characters
	if (strTime1.length != 8 || strTime2.length != 8)
	{
		return intRtnVal;
	}

	var intHour1   = GetNumericVal(strTime1.substring(0, 2));
	var intMinute1 = GetNumericVal(strTime1.substring(3, 5));
	var intSecond1 = GetNumericVal(strTime1.substring(6, 8));
	var intHour2   = GetNumericVal(strTime2.substring(0, 2));
	var intMinute2 = GetNumericVal(strTime2.substring(3, 5));
	var intSecond2 = GetNumericVal(strTime2.substring(6, 8));

	intRtnVal = 0;
	// Check for strTime1 = strTime2
	if (intHour1 == intHour2 && intMinute1 == intMinute2 && intSecond1 == intSecond2)
	{
		return intRtnVal;
	}

	intRtnVal = 1;
	// Check for strTime1 > strTime2
	if ( intHour1 > intHour2 ||
		(intHour1 == intHour2 && intMinute1  > intMinute2) ||
		(intHour1 == intHour2 && intMinute1 == intMinute2 && intSecond1 > intSecond2)
	   )
	{
		return intRtnVal;
	}

	intRtnVal = -1;
	// Check for strTime1 > strTime2
	if ( intHour2 > intHour1 ||
		(intHour2 == intHour1 && intMinute2  > intMinute1) ||
		(intHour2 == intHour1 && intMinute2 == intMinute1 && intSecond2 > intSecond1)
	   )
	{
		return intRtnVal;
	}

	intRtnVal = -100;

	return intRtnVal;
}  // CompareTime()


// Returns true if driver licence is valid. False otherwise.
function IsValidLicence(strLicence)
{
	var blnInvalidLicence = false;
	var strDriverLicence = strLicence;
	
	// A licence must have exactly 15 alpha-numerics
	if (strDriverLicence.length != 15)
	{   
		blnInvalidLicence = true;
	}
	
	// First character must be a letter
	if (blnInvalidLicence != true)
	{
		var strFirstChar = strDriverLicence.substring(0,1);
		
		if (strFirstChar.toLowerCase() < "a" || strFirstChar.toLowerCase() > "z")
		{
			blnInvalidLicence = true;
		}
	}
	
	// Next 14 characters must be numeric
	if (blnInvalidLicence != true)
	{
		var strNext14Char = strDriverLicence.substring(1,15);
		
		if (IsNumeric(strNext14Char) == false)
		{
			blnInvalidLicence = true;
		}
	}

	// Last 2 characters must be < 32
	if (blnInvalidLicence != true)
	{
		var strLast2Char = strDriverLicence.substring(13,15);

		if (GetNumericVal(strLast2Char) >= 32)
		blnInvalidLicence = true;
	}

	return !(blnInvalidLicence);
} // IsValidLicence()
